# Eduardo Zanetta - 20203087

# entrada do raio
r = float(input())

# cálculo do comprimento da circunferência C = 2πR
c = 2 * 3.14 * r

# output com 2 números após a vírgula
print(f'{c:.2f}')