# Eduardo Zanetta - 20203087

n = int(input()) # Input do usuário

number_of_pieces = ((n + 1) * (n + 2)) // 2 # Fórmula para calcular o número de peças de um jogo duplo-n

print(number_of_pieces) # Output