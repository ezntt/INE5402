# -*- coding: utf-8 -*-

# input do usuário
a = int(input())
b = int(input())

# a módulo b = resto da divisão de a por b
print(a % b)